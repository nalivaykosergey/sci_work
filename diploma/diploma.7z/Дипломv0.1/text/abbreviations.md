# Список используемых сокращений {.unnumbered}

## Англоязычные сокращения {.unnumbered}

ONF --- Open Networking Foundation

SDN --- Software-defined Networking

RTT --- Round Trip Time

API --- Application Programming Interface --- программный интерфейс приложения

CLI --- Command line interface --- интерфейс командной строки

HDN --- Hardware Defined Network --- аппаратно определяемая сеть

TCP --- Transmission Control Protocol --- протокол управления передачей

SCTP --- Stream Control Transmission Protocol --- протокол передачи с управлением потоком

UDP --- User Datagram Protocol --- протокол пользовательских датаграмм

QoS --- quality of service --- качество обслуживания

LLDP --- Link Layer Discovery Protocol

TBF --- Token bucket filter

CBF --- Credit Base Fair Queue

HTB --- Hierarchy Token Bucket

RED --- Random Early Detection

SFQ --- Stochastic Fairness Queueing

IP --- Internet Protocol --- межсетевой протокол

## Русскоязычные сокращения {.unnumbered}

ПУСТО