# Список используемых сокращений{.unnumbered}

## Русскоязычные сокращения{.unnumbered}

ОС --- Операционная система

## Англоязычные сокращения{.unnumbered}

AMD --- Advanced Micro Devices

CBQ --- Class Based Queueing

CLI --- Сommand-Line Interface

HTB --- Hierarchy Token Bucket

IP --- Internet Protocol

JSON --- JavaScript Object Notation

PID --- Process Identity Document

QoS --- Quality of Service

RED --- Random Early Detection

RTT --- Round-Trip Time

SCTP --- Stream Control Transmission Protocol

SFQ --- Stochastic Fairness Queueing

SSD --- Solid-State Drive

TBF --- Token Bucket Filter

<!-- tc --- traffic control -->

TCP --- Transmission Control Protocol

UDP --- User Datagram Protocol

